// eslint-disable-next-line @typescript-eslint/no-unused-vars
const PiglinPVPHordes = []

// TODO: (sallen) Use custom game rule
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const PiglinPVPData = {
    numOutposts: 3
}
