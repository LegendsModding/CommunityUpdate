SNIPPET_InheritsFromGameMode("lcu_pvp", () => {
    SetWorldGenDefinition(pvpWorldGenDefinition)
})